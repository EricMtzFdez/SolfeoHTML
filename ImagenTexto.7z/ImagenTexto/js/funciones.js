var aciertos = 0;
var fallos = 0;
var notaActual = 0;

class nota{
    constructor(path, nombre) {
        this.path = path;
        this.nombre = nombre;
    }
}

let notas = new Array();


function inicializar(){
    notas.push (new nota("../img/a.jpg", "a"));
    notas.push (new nota("../img/b.jpg", "b"));
    notas.push (new nota("../img/c.jpg", "c"));
    generarNota()
}


function generarNota(){

    notaActual2 = notaActual;
    notaActual = getRandomInt(0, 3)

    while(notaActual2 == notaActual){
        notaActual = getRandomInt(0, 3)
    }

    console.log(notaActual)

    document.getElementById("img").src= notas[notaActual].path;
}

function check(){
    let label = document.getElementById("LbPuntuacion")

    if(document.getElementById("txTexto").value.toLowerCase() == notas[notaActual].nombre){
        aciertos += 1;
    }else{
        fallos += 1;
    }

    label.innerHTML = "Aciertos: " + aciertos + " | Fallos: " + fallos;
    document.getElementById("txTexto").value = "";
}

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

//Al pulsar enter en el cuadro de texto
//https://stackoverflow.com/questions/905222/prevent-form-submission-on-enter-key-press
const node = document.getElementById("txTexto");
node.addEventListener("keydown", function(event) {
    if (event.key === "Enter") {
        event.preventDefault();

        //Código

        if(!document.getElementById("txTexto").value == ""){
            check();
            generarNota();
        }
    }
});